import React from 'react';

function NepalFlag() {
  return (
    <div className="nepal-flag-container">
      <svg 
        className="nepal-flag" 
        viewBox="0 0 200 200" 
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Flag background - crimson red */}
        <polygon 
          points="10,10 10,190 100,140 190,190 190,10" 
          fill="#DC143C" 
          className="flag-background"
        />
        
        {/* Blue border */}
        <polygon 
          points="10,10 10,190 100,140 190,190 190,10" 
          fill="none" 
          stroke="#003893" 
          strokeWidth="8"
          className="flag-border"
        />
        
        {/* Crescent moon with detailed craters */}
        <circle cx="70" cy="60" r="20" fill="#fff" className="moon-outer" />
        <circle cx="75" cy="55" r="18" fill="#DC143C" className="moon-inner" />
        
        {/* Detailed moon craters */}
        <circle cx="65" cy="50" r="2" fill="#fff" className="moon-crater" />
        <circle cx="70" cy="60" r="3" fill="#fff" className="moon-crater" />
        <circle cx="75" cy="55" r="1.5" fill="#fff" className="moon-crater" />
        <circle cx="72" cy="65" r="2.5" fill="#fff" className="moon-crater" />
        <circle cx="68" cy="58" r="1" fill="#fff" className="moon-crater" />
        
        {/* Twelve-pointed sun with detailed rays */}
        <g className="sun">
          <circle cx="120" cy="130" r="12" fill="#fff" />
          {/* Sun rays */}
          {[...Array(12)].map((_, i) => {
            const angle = (i * 30) * (Math.PI / 180);
            const x1 = 120 + 18 * Math.cos(angle);
            const y1 = 130 + 18 * Math.sin(angle);
            const x2 = 120 + 28 * Math.cos(angle);
            const y2 = 130 + 28 * Math.sin(angle);
            return (
              <line 
                key={i}
                x1={x1} 
                y1={y1} 
                x2={x2} 
                y2={y2} 
                stroke="#fff" 
                strokeWidth="3"
                className="sun-ray"
              />
            );
          })}
          
          {/* Inner sun rays for more detail */}
          {[...Array(12)].map((_, i) => {
            const angle = (i * 30 + 15) * (Math.PI / 180);
            const x1 = 120 + 18 * Math.cos(angle);
            const y1 = 130 + 18 * Math.sin(angle);
            const x2 = 120 + 24 * Math.cos(angle);
            const y2 = 130 + 24 * Math.sin(angle);
            return (
              <line 
                key={`inner-${i}`}
                x1={x1} 
                y1={y1} 
                x2={x2} 
                y2={y2} 
                stroke="#fff" 
                strokeWidth="2"
                className="sun-ray-inner"
              />
            );
          })}
        </g>
        
        {/* Stars around the moon */}
        <circle cx="50" cy="40" r="1.5" fill="#fff" className="star" />
        <circle cx="85" cy="45" r="1" fill="#fff" className="star" />
        <circle cx="60" cy="80" r="1.2" fill="#fff" className="star" />
        <circle cx="90" cy="75" r="1.3" fill="#fff" className="star" />
      </svg>
    </div>
  );
}

export default NepalFlag;