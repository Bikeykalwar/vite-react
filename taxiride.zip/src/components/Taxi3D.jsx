import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera } from '@react-three/drei';

function Taxi3D({ scrollY }) {
  const taxiRef = useRef();
  const wheelRefs = useRef([]);
  const antennaRef = useRef();

  // Animate taxi based on scroll position
  useFrame(() => {
    if (taxiRef.current) {
      // Move taxi up/down based on scroll with smoother motion
      taxiRef.current.position.y = Math.sin(scrollY * 0.01) * 0.3;
      
      // Rotate taxi slightly based on scroll
      taxiRef.current.rotation.y = Math.sin(scrollY * 0.005) * 0.2;
      
      // Rotate wheels with more realistic motion
      const rotation = scrollY * 0.03;
      wheelRefs.current.forEach(wheel => {
        if (wheel) {
          wheel.rotation.z = rotation;
        }
      });
      
      // Animate antenna
      if (antennaRef.current) {
        antennaRef.current.rotation.z = Math.sin(scrollY * 0.02) * 0.1;
      }
    }
  });

  return (
    <>
      <PerspectiveCamera makeDefault position={[0, 1, 5]} />
      <OrbitControls 
        enableZoom={false}
        enablePan={false}
        minPolarAngle={Math.PI / 4}
        maxPolarAngle={Math.PI / 2.5}
      />
      <ambientLight intensity={0.8} />
      <spotLight position={[10, 15, 10]} angle={0.3} penumbra={1} intensity={1.5} castShadow />
      <pointLight position={[-10, -10, -10]} intensity={0.7} />
      <directionalLight position={[5, 5, 5]} intensity={1} />
      
      <group ref={taxiRef} position={[0, 0, 0]} rotation={[0, 0, 0]}>
        {/* Car Body - Main Yellow Body */}
        <mesh position={[0, 0.5, 0]} castShadow>
          <boxGeometry args={[2.4, 0.8, 1.3]} />
          <meshStandardMaterial color="#FFD700" metalness={0.7} roughness={0.1} />
        </mesh>
        
        {/* Car Top - Roof */}
        <mesh position={[0, 1.15, 0]} castShadow>
          <boxGeometry args={[1.6, 0.6, 1.3]} />
          <meshStandardMaterial color="#FFD700" metalness={0.7} roughness={0.1} />
        </mesh>
        
        {/* Windshield */}
        <mesh position={[0, 1.2, 0.7]} rotation={[Math.PI/2, 0, 0]} castShadow>
          <planeGeometry args={[1.5, 0.9]} />
          <meshStandardMaterial color="#87CEEB" transparent opacity={0.7} />
        </mesh>
        
        {/* Rear Window */}
        <mesh position={[0, 1.2, -0.7]} rotation={[Math.PI/2, 0, 0]} castShadow>
          <planeGeometry args={[1.5, 0.9]} />
          <meshStandardMaterial color="#87CEEB" transparent opacity={0.7} />
        </mesh>
        
        {/* Front Bumper */}
        <mesh position={[0, 0.35, 0.7]} castShadow>
          <boxGeometry args={[2.5, 0.2, 0.2]} />
          <meshStandardMaterial color="#111" metalness={0.9} roughness={0.05} />
        </mesh>
        
        {/* Rear Bumper */}
        <mesh position={[0, 0.35, -0.7]} castShadow>
          <boxGeometry args={[2.5, 0.2, 0.2]} />
          <meshStandardMaterial color="#111" metalness={0.9} roughness={0.05} />
        </mesh>
        
        {/* Side Stripes */}
        <mesh position={[1, 0.7, 0]} castShadow>
          <boxGeometry args={[0.15, 0.08, 1.25]} />
          <meshStandardMaterial color="#FF4500" />
        </mesh>
        <mesh position={[-1, 0.7, 0]} castShadow>
          <boxGeometry args={[0.15, 0.08, 1.25]} />
          <meshStandardMaterial color="#FF4500" />
        </mesh>
        
        {/* Wheels with tires and rims */}
        {/* Front Right Wheel */}
        <group position={[1.1, 0.3, 0.6]}>
          <mesh ref={el => wheelRefs.current[0] = el} castShadow>
            <cylinderGeometry args={[0.35, 0.35, 0.2, 16]} />
            <meshStandardMaterial color="#222" />
          </mesh>
          <mesh position={[0, 0, 0]} castShadow>
            <cylinderGeometry args={[0.2, 0.2, 0.21, 16]} />
            <meshStandardMaterial color="#DDD" metalness={0.8} roughness={0.2} />
          </mesh>
          {/* Rim details */}
          <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI/6]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
          <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI/2]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
          <mesh position={[0, 0, 0]} rotation={[0, 0, -Math.PI/6]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
        </group>
        
        {/* Front Left Wheel */}
        <group position={[-1.1, 0.3, 0.6]}>
          <mesh ref={el => wheelRefs.current[1] = el} castShadow>
            <cylinderGeometry args={[0.35, 0.35, 0.2, 16]} />
            <meshStandardMaterial color="#222" />
          </mesh>
          <mesh position={[0, 0, 0]} castShadow>
            <cylinderGeometry args={[0.2, 0.2, 0.21, 16]} />
            <meshStandardMaterial color="#DDD" metalness={0.8} roughness={0.2} />
          </mesh>
          {/* Rim details */}
          <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI/6]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
          <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI/2]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
          <mesh position={[0, 0, 0]} rotation={[0, 0, -Math.PI/6]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
        </group>
        
        {/* Rear Right Wheel */}
        <group position={[1.1, 0.3, -0.6]}>
          <mesh ref={el => wheelRefs.current[2] = el} castShadow>
            <cylinderGeometry args={[0.35, 0.35, 0.2, 16]} />
            <meshStandardMaterial color="#222" />
          </mesh>
          <mesh position={[0, 0, 0]} castShadow>
            <cylinderGeometry args={[0.2, 0.2, 0.21, 16]} />
            <meshStandardMaterial color="#DDD" metalness={0.8} roughness={0.2} />
          </mesh>
          {/* Rim details */}
          <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI/6]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
          <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI/2]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
          <mesh position={[0, 0, 0]} rotation={[0, 0, -Math.PI/6]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
        </group>
        
        {/* Rear Left Wheel */}
        <group position={[-1.1, 0.3, -0.6]}>
          <mesh ref={el => wheelRefs.current[3] = el} castShadow>
            <cylinderGeometry args={[0.35, 0.35, 0.2, 16]} />
            <meshStandardMaterial color="#222" />
          </mesh>
          <mesh position={[0, 0, 0]} castShadow>
            <cylinderGeometry args={[0.2, 0.2, 0.21, 16]} />
            <meshStandardMaterial color="#DDD" metalness={0.8} roughness={0.2} />
          </mesh>
          {/* Rim details */}
          <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI/6]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
          <mesh position={[0, 0, 0]} rotation={[0, 0, Math.PI/2]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
          <mesh position={[0, 0, 0]} rotation={[0, 0, -Math.PI/6]} castShadow>
            <boxGeometry args={[0.03, 0.3, 0.22]} />
            <meshStandardMaterial color="#555" />
          </mesh>
        </group>
        
        {/* Headlights */}
        <mesh position={[0.8, 0.55, 0.71]} castShadow>
          <boxGeometry args={[0.2, 0.15, 0.07]} />
          <meshStandardMaterial color="#FFFFCC" emissive="#FFFF99" emissiveIntensity={2} />
        </mesh>
        <mesh position={[-0.8, 0.55, 0.71]} castShadow>
          <boxGeometry args={[0.2, 0.15, 0.07]} />
          <meshStandardMaterial color="#FFFFCC" emissive="#FFFF99" emissiveIntensity={2} />
        </mesh>
        
        {/* Taillights */}
        <mesh position={[0.8, 0.55, -0.71]} castShadow>
          <boxGeometry args={[0.2, 0.15, 0.07]} />
          <meshStandardMaterial color="#FF3333" emissive="#FF0000" emissiveIntensity={2} />
        </mesh>
        <mesh position={[-0.8, 0.55, -0.71]} castShadow>
          <boxGeometry args={[0.2, 0.15, 0.07]} />
          <meshStandardMaterial color="#FF3333" emissive="#FF0000" emissiveIntensity={2} />
        </mesh>
        
        {/* Door Handles */}
        <mesh position={[0.75, 0.65, 0.66]} castShadow>
          <boxGeometry args={[0.3, 0.05, 0.04]} />
          <meshStandardMaterial color="#444" />
        </mesh>
        <mesh position={[-0.75, 0.65, 0.66]} castShadow>
          <boxGeometry args={[0.3, 0.05, 0.04]} />
          <meshStandardMaterial color="#444" />
        </mesh>
        
        {/* Antenna */}
        <group ref={antennaRef} position={[0, 1.6, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.015, 0.015, 0.5, 8]} />
            <meshStandardMaterial color="#AAA" metalness={0.95} roughness={0.05} />
          </mesh>
          <mesh position={[0, 0.25, 0]} castShadow>
            <sphereGeometry args={[0.05, 8, 8]} />
            <meshStandardMaterial color="#FF0000" emissive="#FF0000" emissiveIntensity={1} />
          </mesh>
        </group>
        
        {/* Taxi Sign on Roof */}
        <mesh position={[0, 1.55, 0]} castShadow>
          <boxGeometry args={[1, 0.08, 0.4]} />
          <meshStandardMaterial color="#FF0000" />
        </mesh>
        <mesh position={[0, 1.55, 0]} castShadow>
          <boxGeometry args={[0.9, 0.09, 0.3]} />
          <meshStandardMaterial color="#FFFF00" emissive="#FFFF00" emissiveIntensity={0.8} />
        </mesh>
        <mesh position={[0, 1.55, 0]} castShadow>
          <boxGeometry args={[0.8, 0.1, 0.2]} />
          <meshStandardMaterial color="#0000FF" emissive="#0000FF" emissiveIntensity={0.5} />
        </mesh>
        
        {/* Side Windows */}
        <mesh position={[0, 0.95, 0.66]} rotation={[0, 0, 0]} castShadow>
          <planeGeometry args={[1.4, 0.5]} />
          <meshStandardMaterial color="#87CEEB" transparent opacity={0.6} />
        </mesh>
        
        {/* Rear License Plate */}
        <mesh position={[0, 0.5, -0.71]} castShadow>
          <boxGeometry args={[0.4, 0.2, 0.04]} />
          <meshStandardMaterial color="#FFF" />
        </mesh>
        <mesh position={[0, 0.5, -0.72]} castShadow>
          <boxGeometry args={[0.35, 0.15, 0.02]} />
          <meshStandardMaterial color="#000" />
        </mesh>
        
        {/* Side Mirrors */}
        <mesh position={[0.9, 0.75, 0.35]} castShadow>
          <boxGeometry args={[0.06, 0.18, 0.03]} />
          <meshStandardMaterial color="#333" />
        </mesh>
        <mesh position={[-0.9, 0.75, 0.35]} castShadow>
          <boxGeometry args={[0.06, 0.18, 0.03]} />
          <meshStandardMaterial color="#333" />
        </mesh>
        
        {/* Exhaust Pipe */}
        <mesh position={[0, 0.4, -0.65]} castShadow>
          <cylinderGeometry args={[0.04, 0.04, 0.15, 8]} />
          <meshStandardMaterial color="#333" />
        </mesh>
      </group>
    </>
  );
}

export default Taxi3D;