// ... existing imports ...
import { useState, useEffect, useCallback } from 'react';
import { Canvas } from '@react-three/fiber';
import './App.css';
import Taxi3D from './components/Taxi3D';
import NepalFlag from './components/NepalFlag';

// Function to get pending drivers
function getPendingDrivers() {
  const storedDrivers = JSON.parse(localStorage.getItem('taxiRideDrivers') || '[]');
  return storedDrivers.filter(driver => !driver.approved);
}

// Function to get approved drivers
function getApprovedDrivers() {
  const storedDrivers = JSON.parse(localStorage.getItem('taxiRideDrivers') || '[]');
  return storedDrivers.filter(driver => driver.approved);
}

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [scrollY, setScrollY] = useState(0);

  // Track scroll position
  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Check for admin panel hash
  useEffect(() => {
    const checkHash = () => {
      if (window.location.hash === '#admin') {
        setCurrentPage('admin');
      }
    };
    
    // Check on initial load
    checkHash();
    
    // Listen for hash changes
    window.addEventListener('hashchange', checkHash);
    
    return () => window.removeEventListener('hashchange', checkHash);
  }, []);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage scrollY={scrollY} />;
      case 'register':
        return <DriverRegistration />;
      case 'drivers':
        return <DriverList />;
      case 'admin':
        return <AdminPanel />;
      default:
        return <HomePage scrollY={scrollY} />;
    }
  };

  return (
    <div className="App">
      <header className="app-header">
        <div className="container">
          <div className="header-content">
            <h1 className="logo">TaxiRide Tihari</h1>
            <nav className="navigation">
              <button 
                className={currentPage === 'home' ? 'nav-button active' : 'nav-button'}
                onClick={() => {
                  setCurrentPage('home');
                  window.location.hash = '';
                }}
              >
                Home
              </button>
              <button 
                className={currentPage === 'register' ? 'nav-button active' : 'nav-button'}
                onClick={() => {
                  setCurrentPage('register');
                  window.location.hash = '';
                }}
              >
                Register as Driver
              </button>
              <button 
                className={currentPage === 'drivers' ? 'nav-button active' : 'nav-button'}
                onClick={() => {
                  setCurrentPage('drivers');
                  window.location.hash = '';
                }}
              >
                Find Drivers
              </button>
              <button 
                className={currentPage === 'admin' ? 'nav-button active' : 'nav-button'}
                onClick={() => setCurrentPage('admin')}
              >
                Admin Panel
              </button>
            </nav>
          </div>
        </div>
      </header>
      <main className="main-content">
        <div className="container">
          {renderPage()}
        </div>
      </main>
      <footer className="app-footer">
        <div className="container">
          <p>&copy; 2025 TaxiRide Tihari. Making transportation easier for everyone in Tihari.</p>
        </div>
      </footer>
    </div>
  );
}

function HomePage({ scrollY }) {
  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="hero-content">
          <div className="flag-animation">
            <NepalFlag />
          </div>
          <h1 className="hero-title">TaxiRide Tihari</h1>
          <h2 className="hero-subtitle">Your Reliable Transportation Partner</h2>
          <p className="hero-description">Book taxis and tempos instantly in Tihari with just one click. No app download needed!</p>
          <div className="hero-buttons">
            <button className="cta-button primary">Book a Ride Now</button>
            <button className="cta-button secondary">Register as Driver</button>
          </div>
        </div>
        <div className="hero-visual">
          <Canvas shadows>
            <Taxi3D scrollY={scrollY} />
          </Canvas>
        </div>
      </section>
      
      <section className="features-section">
        <div className="feature-card">
          <div className="feature-icon">🚕</div>
          <h3>Instant Booking</h3>
          <p>Connect with drivers in real-time through WhatsApp with pre-filled messages</p>
        </div>
        <div className="feature-card">
          <div className="feature-icon">💰</div>
          <h3>Affordable Rides</h3>
          <p>Competitive pricing with no hidden charges. Save money on every ride</p>
        </div>
        <div className="feature-card">
          <div className="feature-icon">⭐</div>
          <h3>Trusted Drivers</h3>
          <p>Vetted and rated drivers for your safety and comfort</p>
        </div>
      </section>
      
      <section className="how-it-works">
        <h2 className="section-title">How TaxiRide Works</h2>
        <div className="steps-container">
          <div className="step-card">
            <div className="step-number">1</div>
            <h3>Find Drivers</h3>
            <p>Browse available drivers in your area</p>
          </div>
          <div className="step-card">
            <div className="step-number">2</div>
            <h3>Book Instantly</h3>
            <p>One-click booking via WhatsApp</p>
          </div>
          <div className="step-card">
            <div className="step-number">3</div>
            <h3>Enjoy Ride</h3>
            <p>Get picked up and reach your destination</p>
          </div>
        </div>
      </section>
      
      <section className="testimonials-section">
        <h2 className="section-title">What Our Users Say</h2>
        <div className="testimonials-container">
          <div className="testimonial-card">
            <div className="testimonial-rating">⭐⭐⭐⭐⭐</div>
            <p>"TaxiRide made it so easy to find a ride home after work. Highly recommended!"</p>
            <div className="testimonial-author">- Sunita Thapa</div>
          </div>
          <div className="testimonial-card">
            <div className="testimonial-rating">⭐⭐⭐⭐⭐</div>
            <p>"As a driver, I've doubled my daily bookings since joining TaxiRide."</p>
            <div className="testimonial-author">- Rajesh Kumar</div>
          </div>
          <div className="testimonial-card">
            <div className="testimonial-rating">⭐⭐⭐⭐⭐</div>
            <p>"The WhatsApp booking system is brilliant - no app needed, just one click!"</p>
            <div className="testimonial-author">- Nirmal Shah</div>
          </div>
        </div>
      </section>
      
      <section className="cta-section">
        <h2>Ready to Get Started?</h2>
        <p>Join hundreds of satisfied users in Tihari</p>
        <div className="cta-buttons">
          <button className="cta-button large">Book a Ride</button>
          <button className="cta-button large secondary">Register as Driver</button>
        </div>
      </section>
    </div>
  );
}

function DriverRegistration() {
  const [formData, setFormData] = useState({
    driverName: '',
    phoneNumber: '',
    vehicleType: '',
    vehicleNumber: '',
    location: ''
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Get existing drivers from localStorage
    const existingDrivers = JSON.parse(localStorage.getItem('taxiRideDrivers') || '[]');
    
    // Create new driver object with unique ID
    const newDriver = {
      id: Date.now(), // Simple ID generation
      ...formData,
      rating: 5.0, // Default rating for new drivers
      approved: false // New drivers need admin approval
    };
    
    // Add new driver to existing drivers
    const updatedDrivers = [...existingDrivers, newDriver];
    
    // Save to localStorage
    localStorage.setItem('taxiRideDrivers', JSON.stringify(updatedDrivers));
    
    console.log('Driver registration data:', newDriver);
    alert('Thank you for registering! Your information has been submitted and is pending admin approval.');
    
    // Reset form
    setFormData({
      driverName: '',
      phoneNumber: '',
      vehicleType: '',
      vehicleNumber: '',
      location: ''
    });
  };

  return (
    <div className="driver-registration">
      <h2>Register as a Driver</h2>
      <p>Join our network of drivers and get more bookings in Tihari</p>
      
      <form className="registration-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="driverName">Full Name</label>
          <input 
            type="text" 
            id="driverName" 
            placeholder="Enter your full name" 
            value={formData.driverName}
            onChange={handleChange}
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="phoneNumber">Phone Number</label>
          <input 
            type="tel" 
            id="phoneNumber" 
            placeholder="Enter your phone number" 
            value={formData.phoneNumber}
            onChange={handleChange}
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="vehicleType">Vehicle Type</label>
          <select 
            id="vehicleType" 
            value={formData.vehicleType}
            onChange={handleChange}
            required
          >
            <option value="">Select vehicle type</option>
            <option value="taxi">Taxi</option>
            <option value="tempo">Tempo</option>
            <option value="auto">Auto Rickshaw</option>
          </select>
        </div>
        
        <div className="form-group">
          <label htmlFor="vehicleNumber">Vehicle Number</label>
          <input 
            type="text" 
            id="vehicleNumber" 
            placeholder="Enter your vehicle number" 
            value={formData.vehicleNumber}
            onChange={handleChange}
            required
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="location">Operating Area</label>
          <input 
            type="text" 
            id="location" 
            placeholder="Enter your primary operating area" 
            value={formData.location}
            onChange={handleChange}
            required
          />
        </div>
        
        <button type="submit" className="submit-button">Register Now</button>
      </form>
      
      <div className="admin-login-link">
        <p>Admin? <button onClick={() => window.location.hash = '#admin'}>Login to Admin Panel</button></p>
      </div>
    </div>
  );
}

function AdminPanel() {
  const [pendingDrivers, setPendingDrivers] = useState([]);
  const [approvedDrivers, setApprovedDrivers] = useState([]);
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [error, setError] = useState('');

  // Hardcoded admin password (in a real app, this would be properly secured)
  const ADMIN_PASSWORD = 'taxiride123';

  const loadDrivers = useCallback(() => {
    setPendingDrivers(getPendingDrivers());
    setApprovedDrivers(getApprovedDrivers());
  }, []);

  useEffect(() => {
    if (isLoggedIn) {
      // Use setTimeout to avoid calling setState directly in effect
      const timer = setTimeout(() => {
        loadDrivers();
      }, 0);
      return () => clearTimeout(timer);
    }
  }, [isLoggedIn, loadDrivers]);

  const handleLogin = (e) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setIsLoggedIn(true);
      setError('');
    } else {
      setError('Invalid password');
    }
  };

  const handleApprove = (driverId) => {
    const allDrivers = JSON.parse(localStorage.getItem('taxiRideDrivers') || '[]');
    const updatedDrivers = allDrivers.map(driver => 
      driver.id === driverId ? { ...driver, approved: true } : driver
    );
    localStorage.setItem('taxiRideDrivers', JSON.stringify(updatedDrivers));
    loadDrivers();
  };

  const handleReject = (driverId) => {
    const allDrivers = JSON.parse(localStorage.getItem('taxiRideDrivers') || '[]');
    const updatedDrivers = allDrivers.filter(driver => driver.id !== driverId);
    localStorage.setItem('taxiRideDrivers', JSON.stringify(updatedDrivers));
    loadDrivers();
  };

  if (!isLoggedIn) {
    return (
      <div className="admin-login">
        <h2>Admin Login</h2>
        <form onSubmit={handleLogin}>
          <div className="form-group">
            <label htmlFor="password">Admin Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {error && <p className="error">{error}</p>}
          <button type="submit" className="submit-button">Login</button>
        </form>
      </div>
    );
  }

  return (
    <div className="admin-panel">
      <div className="admin-header">
        <h2>Admin Panel</h2>
        <button onClick={() => setIsLoggedIn(false)} className="logout-button">Logout</button>
      </div>
      
      <div className="admin-sections">
        <div className="admin-section">
          <h3>Pending Driver Approvals ({pendingDrivers.length})</h3>
          {pendingDrivers.length === 0 ? (
            <p className="no-drivers">No pending drivers for approval</p>
          ) : (
            <div className="drivers-grid">
              {pendingDrivers.map(driver => (
                <div key={driver.id} className="driver-card pending">
                  <div className="driver-info">
                    <h3>{driver.driverName}</h3>
                    <p className="vehicle-details">{driver.vehicleType} - {driver.vehicleNumber}</p>
                    <p className="location">📍 {driver.location}</p>
                    <p className="phone">📞 {driver.phoneNumber}</p>
                  </div>
                  <div className="admin-actions">
                    <button 
                      className="approve-button"
                      onClick={() => handleApprove(driver.id)}
                    >
                      Approve
                    </button>
                    <button 
                      className="reject-button"
                      onClick={() => handleReject(driver.id)}
                    >
                      Reject
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="admin-section">
          <h3>Approved Drivers ({approvedDrivers.length})</h3>
          {approvedDrivers.length === 0 ? (
            <p className="no-drivers">No approved drivers yet</p>
          ) : (
            <div className="drivers-grid">
              {approvedDrivers.map(driver => (
                <div key={driver.id} className="driver-card approved">
                  <div className="driver-info">
                    <h3>{driver.driverName}</h3>
                    <p className="vehicle-details">{driver.vehicleType} - {driver.vehicleNumber}</p>
                    <p className="location">📍 {driver.location}</p>
                    <p className="phone">📞 {driver.phoneNumber}</p>
                    <p className="rating">⭐ {driver.rating}/5.0</p>
                  </div>
                  <div className="admin-actions">
                    <button 
                      className="reject-button"
                      onClick={() => handleReject(driver.id)}
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function DriverList() {
  const [drivers, setDrivers] = useState([
    { 
      id: 1, 
      driverName: "Ram Kumar", 
      vehicleType: "Taxi", 
      vehicleNumber: "BA 12 KH 3456", 
      phoneNumber: "+977 98XXXXXXXX", 
      rating: 4.8,
      location: "Tihari Bazaar",
      approved: true
    },
    { 
      id: 2, 
      driverName: "Shyam Thapa", 
      vehicleType: "Tempo", 
      vehicleNumber: "BA 15 PA 7890", 
      phoneNumber: "+977 98XXXXXXXX", 
      rating: 4.6,
      location: "Tihari Chowk",
      approved: true
    },
    { 
      id: 3, 
      driverName: "Hari Magar", 
      vehicleType: "Auto Rickshaw", 
      vehicleNumber: "BA 10 AU 1234", 
      phoneNumber: "+977 98XXXXXXXX", 
      rating: 4.9,
      location: "Tihari Hospital",
      approved: true
    },
    { 
      id: 4, 
      driverName: "Krishna Rai", 
      vehicleType: "Taxi", 
      vehicleNumber: "BA 09 TX 5678", 
      phoneNumber: "+977 98XXXXXXXX", 
      rating: 4.7,
      location: "Tihari College",
      approved: true
    }
  ]);

  // Load approved drivers from localStorage when component mounts
  useEffect(() => {
    const storedDrivers = JSON.parse(localStorage.getItem('taxiRideDrivers') || '[]');
    const approvedDrivers = storedDrivers.filter(driver => driver.approved);
    if (approvedDrivers.length > 0) {
      // Use setTimeout to avoid calling setState directly in effect
      const timer = setTimeout(() => {
        setDrivers(prevDrivers => [...prevDrivers, ...approvedDrivers]);
      }, 0);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleBooking = (driver) => {
    const message = `Hello ${driver.driverName}, I'd like to book your ${driver.vehicleType} (${driver.vehicleNumber}) for a ride. I'm currently at [Your Location] and need to go to [Destination].`;
    const whatsappUrl = `https://wa.me/${driver.phoneNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const shareLiveLocation = (driver) => {
    // Check if geolocation is supported
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser");
      return;
    }

    // Get current position
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const googleMapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
        const message = `Hello ${driver.driverName}, I'm booking your ${driver.vehicleType} (${driver.vehicleNumber}). Here is my current location: ${googleMapsUrl}. Please come to pick me up.`;
        const whatsappUrl = `https://wa.me/${driver.phoneNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
      },
      (error) => {
        console.error("Error getting location:", error);
        alert("Unable to get your location. Please try again or share your location manually in WhatsApp.");
        
        // Fallback to regular booking if location sharing fails
        const message = `Hello ${driver.driverName}, I'd like to book your ${driver.vehicleType} (${driver.vehicleNumber}) for a ride. I'm currently at [Your Location] and need to go to [Destination].`;
        const whatsappUrl = `https://wa.me/${driver.phoneNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`;
        window.open(whatsappUrl, '_blank');
      }
    );
  };

  return (
    <div className="driver-list">
      <h2>Available Drivers</h2>
      {drivers.length === 0 ? (
        <p className="no-drivers">No drivers available at the moment</p>
      ) : (
        <div className="drivers-grid">
          {drivers.map(driver => (
            <div key={driver.id} className="driver-card">
              <div className="driver-info">
                <h3>{driver.driverName}</h3>
                <p className="vehicle-details">{driver.vehicleType} - {driver.vehicleNumber}</p>
                <p className="location">📍 {driver.location}</p>
                <p className="phone">📞 {driver.phoneNumber}</p>
                <p className="rating">⭐ {driver.rating}/5.0</p>
              </div>
              <div className="booking-actions">
                <button 
                  className="book-button"
                  onClick={() => handleBooking(driver)}
                >
                  Book Now
                </button>
                <button 
                  className="location-button"
                  onClick={() => shareLiveLocation(driver)}
                >
                  Share Live Location
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default App;